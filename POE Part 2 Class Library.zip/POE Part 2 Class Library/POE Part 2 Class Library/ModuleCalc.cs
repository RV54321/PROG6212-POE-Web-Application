﻿using System;
using System.Collections.Generic;
using System.Text;
//PROG6212 POE Part 2 - Class Library
//Holds all the classes that the WPF will use under its 'CALCULATIONS' Heading
//Holds Get and Set of variables

namespace Part_1_Class_Library
{
    class ModuleCalc
    {
        //Varaibles
        public int mhoursspent { get; set; }
        public string mmodule { get; set; }
        public DateTime mcertaindate { get; set; }
    }
}
