﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
//PROG6212 POE Part 2 - Class Library
//This class is used in the 'Login' and 'Regitser procedures, to store the password Hash ('#") using System.Collections.Generic

namespace Part_1_Class_Library
{
    public class UtilityClass
    {
        public string EncryptData(string password)
        {
            //Encrypting method, hashng the password
            //Adopted here: http://www.dotnetfunda.com/forums/show/16822/decrypt-password-in-aspnet

            string ms = string.Empty;
            byte[] encode = new byte[password.Length];
            encode = Encoding.UTF8.GetBytes(password);
            ms = Convert.ToBase64String(encode);
            return ms;
        }
        public string Decryptdata(string encryptpwd)
        {
            //Decryption method
            string decryptpwd = string.Empty;
            UTF8Encoding encodepwd = new UTF8Encoding();
            Decoder Decode = encodepwd.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encryptpwd);
            int charCount = Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            decryptpwd = new String(decoded_char);
            return decryptpwd;
        }
    }
}
