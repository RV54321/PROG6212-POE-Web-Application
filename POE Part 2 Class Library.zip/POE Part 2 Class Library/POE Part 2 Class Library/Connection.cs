﻿using System;
using System.Collections.Generic;
using System.Text;
//PROG6212 POE Part 2 - Class Library
//Connection.cs (Used to store the connection string to connect to the sql database, for data storage)

namespace Part_1_Class_Library
{
    class Connection
    {
        public const String conn = "Data Source=ML-RefVm-631348;Initial Catalog=PROG6212POEPart2;Integrated Security=True";
    }
}
