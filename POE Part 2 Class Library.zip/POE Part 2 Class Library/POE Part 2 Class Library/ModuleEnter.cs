﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
//PROG6212 POE Part 2 - Class Library
//Holds all the classes that the WPF will use under its 'DATA ENTRIES' Heading
//Holds Get and Set of variables

namespace Part_1_Class_Library
{
    public class ModuleEnter
    {
        //Variables
        //'DATA ENTRIES'
        public String mcode { get; set; }
        public String mname { get; set; }
        public int mcredits { get; set; }
        public int mclasshours { get; set; }
        public DateTime Mstart { get; set; }
        //Number of weeks
        public int mweeks { get; set; }
        //Start date of first week
        public DateTime mstart { get; set; }

        //'CALCULATIONS'
        public int mselfstudy { get; set; }
    }
}
